"""MCP Server for AWS Glue Data Quality operations."""

__version__ = "0.1.0"